﻿namespace Excersice1.BL
{
    public class Course
    {
        int id;
        string title;
        string URL;
        double rating;
        int numberOfReviews;
        int instructorsId;
        string imageReference;
        int duration;
        string lastUpdate;
        static List<Course> coursesList = new List<Course>();

        public Course() { }

        public Course(int id, string title, string URL, double rating, int numberOfReviews, int instructorsId, string imageReference, int duration, string lastUpdate)
        {
            Id = id;
            Title1 = title;
            URL1 = URL;
            Rating1 = rating;
            NumberOfReviews1 = numberOfReviews;
            InstructorsId1 = instructorsId;
            ImageReference1 = imageReference;
            Duration1 = duration;
            LastUpdate1 = lastUpdate;
        }

        public bool Insert()
        {
            foreach (Course course in coursesList)
            {
                if (course.id == this.id || course.title == this.title)
                {
                    return false;
                }
            }
            coursesList.Add(this);
            return true;
        }

        static public List<Course> Read()
        {
            return coursesList;
        }

        public int Id { get => id; set => id = value; }
        public string Title1 { get => title; set => title = value; }
        public string URL1 { get => URL; set => URL = value; }
        public double Rating1 { get => rating; set => rating = value; }
        public int NumberOfReviews1 { get => numberOfReviews; set => numberOfReviews = value; }
        public int InstructorsId1 { get => instructorsId; set => instructorsId = value; }
        public string ImageReference1 { get => imageReference; set => imageReference = value; }
        public int Duration1 { get => duration; set => duration = value; }
        public string LastUpdate1 { get => lastUpdate; set => lastUpdate = value; }
    }
}
